<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <script src="<?php echo e(asset('tinymce/tinymce.min.js')); ?>"></script>
    <!-- TinyMCE -->
    <script>
        tinymce.init({
            selector: '#text',
            language: 'ru',
        });
    </script>
    <!-- .TinyMCE -->

    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
    <title>Панель администратора</title>
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="navbar-nav">
                    <a class="nav-item nav-link active" href="<?php echo e(route('admin.index')); ?>">Главная</a>
                    <?php if(auth()->guard()->check()): ?>
                        <a class="nav-item nav-link" href="<?php echo e(route('logout')); ?>">Выход</a>
                    <?php endif; ?>
                </div>
            </nav>

            <?php echo $__env->yieldContent('content'); ?>


        </div>
    </div>
</div>

<script src="<?php echo e(asset('js/scripts.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\OSNEW\OpenServer\domains\manager.loc\resources\views/post/layout.blade.php ENDPATH**/ ?>