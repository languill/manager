<?php $__env->startSection('content'); ?>
    <h2>Создание поста</h2>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('post.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSNEW\OpenServer\domains\manager.loc\resources\views/post/create.blade.php ENDPATH**/ ?>
