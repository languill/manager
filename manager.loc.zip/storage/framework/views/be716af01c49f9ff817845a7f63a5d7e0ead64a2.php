<?php $__env->startSection('content'); ?>
    <h2 class="text-success">Редактирование поста</h2>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="text-danger"><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('post.store', ['id' => $post->id])); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label for="title">Заголовок</label>
            <input name="title" type="text" class="form-control" id="title" value="<?php echo e($post->title); ?>">
        </div>

        <div class="form-group">
            <label for="text">Текст</label>
            <textarea name="text" id="text" class="form-control"><?php echo e($post->text); ?></textarea>
        </div>

        <div class="form-group">
            <label for="image">Фотография</label>
            <img src="/<?php echo e($post->image); ?>" class="img-thumbnail" style="width:100px">
            <input name="image" type="file" class="form-control" id="image">
        </div>

        <button type="submit" class="btn btn-success">Изменить</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('post.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSNEW\OpenServer\domains\manager.loc\resources\views/post/edit.blade.php ENDPATH**/ ?>