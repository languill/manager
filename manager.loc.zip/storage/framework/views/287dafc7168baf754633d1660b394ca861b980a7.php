<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
    <title>Панель администратора</title>
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="navbar-nav">
                    <a class="nav-item nav-link active" href="<?php echo e(route('admin.index')); ?>">Главная</a>
                    <?php if(auth()->guard()->check()): ?>
                        <a class="nav-item nav-link" href="<?php echo e(route('logout')); ?>">Выход</a>
                    <?php endif; ?>
                </div>
            </nav>
            <h1 class="text-primary text-center mb-5">Панель администратора</h1>
            <h5 class="text-primary text-center">Добро пожаловать, <?php echo e($userName); ?>!</h5>

            <a href="<?php echo e(route('posts.create')); ?>" class="btn btn-success">Создать</a>
            <hr>
            <?php if(session('success')): ?>
                <div class="alert alert-success p-3">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Название</th>
                            <th scope="col">Картинка</th>
                            <th scope="col">Редактировать</th>
                            <th scope="col">Удалить</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $i = 1; ?>
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td scope="row"><?php echo e($i); ?></td>
                                <td><?php echo e($post->title); ?></td>
                                <td><img src="<?php echo e($post->image); ?>" class="img-thumbnail" style="width:100px"></td>
                                <td><a href="<?php echo e(route('post.edit', ['id' => $post->id])); ?>" class="btn btn-warning">Изменить</a></td>
                                <td>
                                    <form action="<?php echo e(route('post.delete', ['id' => $post->id])); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-danger" type="submit">Удалить</button>
                                    </form>
                                </td>
                            </tr>
                         <?php $i++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>
</div>

<div class="d-flex flex-column min-vh-20 mt-5 text-center">
    <footer class="flex-fill text-white">
        <?php echo e($date); ?>

    </footer>
</div>
<script src="<?php echo e(asset('js/scripts.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\OSNEW\OpenServer\domains\manager.loc\resources\views/admin/index.blade.php ENDPATH**/ ?>