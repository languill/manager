<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
    <title>Регистрация</title>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-6 mx-auto mt-5 text-center">
                <h1 class="text-primary mb-5">Регистрация</h1>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="text-danger"><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>


                <form method="post" action="<?php echo e(route('register.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="name">Имя</label>
                        <input name="name" id="name" type="text" class="form-control"
                               placeholder="Имя" value="<?php echo e(old('name')); ?>">
                    </div>

                    <div class="form-group">
                        <label for="email">Email</label>
                        <input name="email" id="email" type="text" class="form-control"
                               placeholder="your-email@mail.ru" value="<?php echo e(old('email')); ?>">
                    </div>

                    <div class="form-group">
                        <label for="password">Пароль</label>
                        <input name="password" id="password" type="password" class="form-control">
                    </div>

                    <div class="form-group">
                        <label for="password_confirmation">Подтверждение пароля</label>
                        <input name="password_confirmation" id="password_confirmation" type="password" class="form-control">
                    </div>

                    <button class="btn btn-primary" type="submit">Регистрация</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\OSNEW\OpenServer\domains\manager.loc\resources\views/user/create.blade.php ENDPATH**/ ?>